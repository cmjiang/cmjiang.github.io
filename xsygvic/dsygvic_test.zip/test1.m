clear all; close all;
load harmonic1d
etol = 1e-10;
n = 112;
sA = Hloc + F*G*F';
sB = S;
A = full(sA);
B = full(sB);
[V,D] = eig(B);
d = diag(D);
m = sum(d>1e-6);
p = find(d <= 1e-6);
delta = 1e-6;
% delta = 0;
D(p,p) = delta*D(p,p);
B = V*D*V';
A = 0.5*(A+A');
B = 0.5*(B+B');

[k, X, a] = dsygvic( n, A, B, etol );
[Y, b] = dsygv(A,B);
% [Y, b] = eig(A,B);
if ( k(1) > 0 )
    r1 = norm(A*X-B*X*a,'fro')/...
         (n*norm(A,'fro')*norm(X,'fro'))
    r2 = norm(A*Y-B*Y*b,'fro')/...
         (n*norm(A,'fro')*norm(Y,'fro'))
     sa = sort(diag(a));
     sb = sort(diag(b));
end
