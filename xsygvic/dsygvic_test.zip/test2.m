clear all;
etol = 1e-10;
delta = 1e-14;
A = [ 6  0  0  0  0  0  1  0;
      0  5  0  0  0  0  0  1;
      0  0  4  0  0  0  0  0;
      0  0  0  3  0  0  0  0;
      0  0  0  0  2  0  0  0;
      0  0  0  0  0  1  0  0;
      1  0  0  0  0  0  1  0;
      0  1  0  0  0  0  0  1];
dB = [1 0.1 0.001 0.00002 delta delta delta delta];
B = diag(dB);
n = size(A,2);
M = rand(n);
Q = orth(M);
A = Q'*A*Q;
B = Q'*B*Q;
A = 0.5*(A+A');
B = 0.5*(B+B');

[k, X, a] = dsygvic( n, A, B, etol );
[Y, b] = dsygv(A,B);
% [Y, b] = eig(A,B,'chol');
if ( k(1) > 0 )
    r1 = norm(A*X-B*X*a,'fro')/...
         (n*norm(A,'fro')*norm(X,'fro'))
    r2 = norm(A*Y-B*Y*b,'fro')/...
         (n*norm(A,'fro')*norm(Y,'fro'))
    sa = sort(diag(a));
    sb = sort(diag(b));
end
    