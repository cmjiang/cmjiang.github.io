function [X, lambda] = dsygv(A, B)
L = chol(B,'lower');
A1 = L\A*(inv(L))';
[U,lambda] = eig(A1);
X = (inv(L))'*U;
