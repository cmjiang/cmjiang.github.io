function [ro, v, r, k]=ppm(A,C,t,alpha,tol_ppm,k_ppm)

% Projected power method to solve :   max  x'Ax 
% ---------------------------------   st.  Cx = 0
n = size(A,2);
B = alpha*speye(n)-A;
r = zeros(k_ppm,1);
n0 = C*t;
gamma = sqrt(1-norm(n0)^2);
v = n0;
for k=1:k_ppm
    y = B*v;
    x = y - C*(C'*y);
    vk = gamma*x/norm(x)+n0;
    v = vk;
    r(k) = v'*A*v;
    if mod(k,1000)==0
        disp(['PPM iter ' num2str(k) ' Res ' num2str(r(k))]);
    end
    if r(k) < tol_ppm
        disp('Converged..');
        break
    end  
end
ro = r(k);
end
