clear variables; close all;
tt = tic;

%% Input data

% Image name
imgName = 'camel';

% Read in point from user input(0) or file(1)
ifFile = 1;

% Parameters for the solver
tol_ppm = 1e-3;
k_ppm = 4000;
alpha = 1;

% Read in image and show it
Img = imread(strcat('data/',imgName,'.jpg'));
Imgo = Img;
[nr,nc,nb] = size(Img);
n = nr * nc;
if (nb > 1)
    Img = double(rgb2gray(Img));
else
    Img = double(Img);
end
figure;clf;imagesc(Img);colormap(gray);
axis off;set(gca,'position',[0 0 1 1],'units','normalized');

% Input the constraints points 'pts1' and 'pts2'
pts = readinPoints(ifFile,imgName,2);

%% Compute the Laplacian
disp('start to compute W');
tw = tic;
[W,d] = computeWd(Img);
ttw = toc(tw);

disp('computing C t');
tc = tic;
[C, t] = createConstraintMatrixHomo(pts{1},pts{2},nr,nc,0);
C = sparse(C);
ttc = toc(tc);

disp('computing L');
tl = tic;
L = spdiags(d,0,n,n) - W;
ttl = toc(tl);

clear W;
disp('computing P');
tp = tic;
Dinvsqrt = 1./sqrt(d+eps);
P = spmtimesd(L,Dinvsqrt,Dinvsqrt);
ttp = toc(tp);
clear L d Dinvsqrt

%% Projected power method
disp('computing x');
[lam, x, r, itppm] = ppm(P,C',t,alpha,tol_ppm,k_ppm);
postProcessPPM(x,Img,Imgo,pts{1},pts{2});
