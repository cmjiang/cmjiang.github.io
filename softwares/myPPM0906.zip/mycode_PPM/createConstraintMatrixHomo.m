function [C,t] = createConstraintMatrixHomo(pts1,pts2,nr,nc,...
    boolMustLinkOnly)
%
%   purpose:
%      create the matrix B for the constraints Bv=0
%   Input:
%      pts1: points selected and labeled for cluster 1
%      pts2: points selected and labeled for cluster 2
%      nr:   number of rows of image I
%      nc:   number of coumns of image I
%   Output:
%      C: the constraints matrix
%
n = nr*nc;
BP1 = round(pts1);
x1 = BP1(:,1);
y1 = BP1(:,2);
m1 = size(BP1,1);

if (boolMustLinkOnly == 0)
    BP2 = round(pts2);
    x2 = BP2(:,1);
    y2 = BP2(:,2);
    m2 = size(BP2,1);
end
%%   homogenous

% if (boolMustLinkOnly == 0)
%     m = m1+m2-1;
%     C = zeros(m1+m2-1,n);
%     idx1 = (x1(1)-1)*nr+y1(1);
%     for i = 2:m1
%         idx = (x1(i)-1)*nr+y1(i);
%         C(i-1, idx1)=1;
%         C(i-1, idx)= -1;
%     end
%     for i = m1+1:m1+m2
%         idx = (x2(i-m1)-1)*nr+y2(i-m1);
%         C(i-1, idx1)=1;
%         C(i-1, idx) =1;
%     end
% else
%     m = m1-1;
%     C = zeros(m1-1,n);
%     idx1 = (x1(1)-1)*nr+y1(1);
%     for i = 2:m1
%         idx = (x1(i)-1)*nr+y1(i);
%         C(i-1, idx1)=1;
%         C(i-1, idx)= -1;
%     end
% end
%% imhomogenous

if (boolMustLinkOnly == 0)
    m = m1+m2;
    t = zeros(m,1);
    C = zeros(m,n);
    for i = 1:m1
        idx = (x1(i)-1)*nr+y1(i);
        C(i, idx)=1;
        t(i) = 1/sqrt(n);
    end
    for i = m1+1:m
        idx = (x2(i-m1)-1)*nr+y2(i-m1);
        C(i, idx)=1;
        t(i) = -1/sqrt(n);
    end
else
    m = m1;
    C = zeros(m,n);
    t = zeros(m,1);
    for i = 1:m
        idx = (x1(i)-1)*nr+y1(i);
        C(i, idx)=1;
        t(i) = 1/sqrt(n);
    end
end
% B = zeros(m1+m2,n);
% c = zeros(m1+m2,1);
% for i = 1:m1
%     j = (x1(i)-1)*nr+y1(i);
%     B(i,j) = 1;
%     c(i) = 1/sqrt(n);
% end
% for i = m1+1:m1+m2;
%     j = (x2(i-m1)-1)*nr+y2(i-m1);
%     B(i,j) = 1;
%     c(i) = -1/sqrt(n);
% end









