function postProcessNoConstraints(X,Img,Imgo)
[nr,nc,~] = size(Img);
n = nr*nc;
figure;
Y = zeros(n,2);
for i = 1:n
    Y(i,:) = X(i,:)/norm(X(i,:));
end
c = kmeans(Y,2);
Label = reshape(c,nr,nc);
bw = edge(Label,0.01);
J1=showmask(Img,imdilate(bw,ones(2,2)));
imagesc(J1);
colormap(gray);
axis off;
set(gca,'position',[0 0 1 1],'units','normalized');


figure
Labelb = Label(1,1);
Imgt = Imgo;
for i = 1:nr
    for j = 1:nc
        if(Label(i,j)==Labelb)
            Imgt(i,j,1) = 0;
            Imgt(i,j,2) = 0;
            Imgt(i,j,3) = 0;
        end
    end
end
image(Imgt);
axis off;
set(gca,'position',[0 0 1 1],'units','normalized');
