function pts = readinPoints(ifFile,imgName,numLabelSets)

colorSet = {'b','g','y','c','m'};
if (ifFile == 1)
    % Read 'pts' in constraint points
    load(strcat('pts_', imgName, '.mat'));
    figure(1);
    hold on;
    for i = 1:numLabelSets
        scatter(pts{i}(:,1),pts{i}(:,2),100,colorSet{i},'filled');
    end
    hold off;
else
    figure(1);
    hold on;
    for i = 1:numLabelSets
        [x, y] = ginput;
        pts{i} = [x,y];
        scatter(pts{i}(:,1),pts{i}(:,2),100,colorSet{i},'filled');
    end
    hold off;
end
end