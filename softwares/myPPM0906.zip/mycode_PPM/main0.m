clear variables; close all;
tt = tic;

%% Input data

% Image name
imgName = 'camel';

% Read in image and show it
Img = imread(strcat('data/',imgName,'.jpg'));
Imgo = Img;
[nr,nc,nb] = size(Img);
n = nr * nc;
if (nb > 1)
    Img = double(rgb2gray(Img));
else
    Img = double(Img);
end
figure;clf;imagesc(Img);colormap(gray);
axis off;set(gca,'position',[0 0 1 1],'units','normalized');

%% Compute the Laplacian
disp('start to compute W');
[W,d] = computeWd(Img);

disp('computing L');
L = spdiags(d,0,n,n) - W;

clear W;
disp('computing P');
tp = tic;
Dinvsqrt = 1./sqrt(d+eps);
P = spmtimesd(L,Dinvsqrt,Dinvsqrt);
ttp = toc(tp);
clear L d Dinvsqrt

[X,D] = eigs(P,6,'sm');
postProcessNoConstraints(X(:,2:3),Img,Imgo);
% %% Projected power method
% disp('computing x');
% [lam, x, r, itppm] = ppm(P,C',t,alpha,tol_ppm,k_ppm);
% postProcessPPM(x,Img,Imgo,pts{1},pts{2});
