function postProcessPPM(x,Img,Imgo,pts1,pts2)
[nr,nc,~] = size(Img);
figure;
c = x>0;
Label = reshape(c,nr,nc);
bw = edge(Label,0.01);
J1=showmask(Img,imdilate(bw,ones(2,2)));
imagesc(J1);
colormap(gray);
axis off;
set(gca,'position',[0 0 1 1],'units','normalized');
hold on;
h = plot(pts1(:,1),pts1(:,2),'bo','MarkerSize',5);
set(h,'linewidth',5);
h = plot(pts2(:,1),pts2(:,2),'go','MarkerSize',5);
set(h,'linewidth',5);
hold off;
figure
Labelb = Label(1,1);
Imgt = Imgo;
for i = 1:nr
    for j = 1:nc
        if(Label(i,j)==Labelb)
            Imgt(i,j,1) = 0;
            Imgt(i,j,2) = 0;
            Imgt(i,j,3) = 0;
        end
    end
end
image(Imgt);
axis off;
set(gca,'position',[0 0 1 1],'units','normalized');
