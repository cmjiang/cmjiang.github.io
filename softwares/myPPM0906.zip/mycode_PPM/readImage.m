function [img,imgo,nr,nc] = readImage(imgName)
img = imread(strcat('data/',imgName,'.jpg'));
imgo = img;
[nr,nc,nb] = size(img);
if (nb > 1)
    img = double(rgb2gray(img));
else
    img = double(img);
end
figure(1);clf;imagesc(img);colormap(gray);
axis off;set(gca,'position',[0 0 1 1],'units','normalized');
end